const chart = document.querySelector("#chart").getContext('2d');

// Generar datos aleatorios para Temperatura
const temperaturaData = Array.from({ length: 12 }, () => Math.floor(Math.random() * 100));
// Generar datos aleatorios para Plástico
const plasticoData = Array.from({ length: 12 }, () => Math.floor(Math.random() * 1000));

// creación de la gráfica
new Chart(chart, {
    type: 'line',
    data: {
        labels: ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'],
        datasets: [{
                label: 'Temperatura',
                data: temperaturaData,
                borderColor: 'red',
                borderWidth: 2
            },
            {
                label: 'Plastico',
                data: plasticoData,
                borderColor: 'blue',
                borderWidth: 2
            },
        ]
    },
    options: {
        responsive: true
    }
});


const menuBtn = document.querySelector('#menu-btn');
const closeBtn = document.querySelector('#close-btn');
const sidebar = document.querySelector('aside');

menuBtn.addEventListener('click', () => {
    sidebar.style.display = 'block';
});

closeBtn.addEventListener('click', () => {
    sidebar.style.display = 'none';
});


//modo oscuro 

const themeBtn= document.querySelector('.theme-btn');
themeBtn.addEventListener('click',()=>{
    document.body.classList.toggle('dark-theme');
    themeBtn.querySelector('span:first-child').classList.toggle('active');
    themeBtn.querySelector('span:last-child').classList.toggle('active');
})