 // conexión MQTT
 var hostname = "mqtt-dashboard.com";
 var port = 8884;
 var clientId = "clientId-kIvSC5zoI4";
 clientId += new Date().getUTCMilliseconds();
 var username = "webclient";
 var password = "Super$icher123";
 var subscriptions = ["temperaturejo", "botellasjo", "personasjo"];
 var mqttClient;

 mqttClient = new Paho.MQTT.Client(hostname, port, clientId);
 mqttClient.onMessageArrived = MessageArrived;
 mqttClient.onConnectionLost = ConnectionLost;
 Connect();

 // iniciamos una conexión con el servidor MQTT
 function Connect() {
     mqttClient.connect({
         onSuccess: Connected,
         onFailure: ConnectionFailed,
         keepAliveInterval: 10,
         userName: username,
         useSSL: true,
         password: password
     });
 }

 // callback para la conexión exitosa
 function Connected() {
     console.log("Connected");
     subscriptions.forEach(function(topic) {
         mqttClient.subscribe(topic);
     });
 }

 // callback para la conexión fallida
 function ConnectionFailed(res) {
     console.log("Connect failed: " + res.errorMessage);
 }

 // Callback para la pérdida de conexión
 function ConnectionLost(res) {
     if (res.errorCode != 0) {
         console.log("Connection lost: " + res.errorMessage);
         Connect();
     }
 }


 
    // aqui proceso lso mensajes qu eentran mqtt
function MessageArrived(message)
 {
    
 console.log(message.destinationName + " : " + message.payloadString);
 var topic = message.destinationName;
 var data = parseFloat(message.payloadString); //convierto mis valores a numeros

 if (topic === "temperaturejo")
     {
     // realixo mi calculo 
     var voltage = (data / 4095) * 5000; // Convertir el valor del ADC a milivoltios (5V)
     var temperature = voltage / 10; // factor dde escala sensopr

     // aqui actualizo la pagina web
     document.getElementById("temperature").textContent = temperature.toFixed(2) + " °C";
    } 
 else if(topic === "botellasjo")
    {
    document.getElementById("botellas").textContent = data + "%";
    }
 else if(topic === "personasjo")
    {
        document.getElementById("person").textContent = data ;
    }
}